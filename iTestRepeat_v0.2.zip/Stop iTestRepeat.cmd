taskkill /IM "iTestRepeat.exe" /F
timeout /t 10